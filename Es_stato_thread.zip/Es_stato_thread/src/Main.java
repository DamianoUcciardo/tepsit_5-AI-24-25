//damiano ucciardo 5^AI

import java.util.Scanner;

public class Main {
	//main
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("Quanti thread vuoi stampare ? \n ");
		int t = s.nextInt(); 
		
		System.out.print("Quanto vuoi  aspettare ? \n ");
		int n = s.nextInt(); 
		
		System.out.print("Inserisci un numero compreso tra 0 ed n \n ");
		int x = s.nextInt(); 
		
		//controllo se x è maggiore di n
		while(x > n) {
			System.out.print("Inserisci un numero minore di n \n ");
			x = s.nextInt();
			System.out.print(" \n ");
		}
		
		//creo il vettore contenente i thread
		Thread[] vet = new Thread[t];
		
		//creo i t thread
		for (int i = 0; i < vet.length; i++) {
			Contatore ogg = new Contatore(n,x);
			vet[i] = new Thread(new Contatore(n,x));
		}
		
		for ( int i = 0; i < vet.length; i++) {
			vet[i].start(); //startiamo il thread 
		}
		
		//monitoraggio dei thread per capire se stanno ancora attivi 
		boolean completati = true; 
		
		while(completati) {
			for(int i = 0; i < vet.length; i++) {
				if(vet[i].isAlive()) {
					System.out.println("Thread " + i + " sempre attivo  \n ");
				} else {
					System.out.println("Thread " + i + " COMPLETATO \n ");
				}
			}
			
			if(completati) {
				System.out.println("Tutti Thread completati ");
			}
			
			try {
				Thread.sleep(1000); //viene atteso un secondo
			} catch (InterruptedException e) {
				e.printStackTrace();    
			}
			
		}
	}
}