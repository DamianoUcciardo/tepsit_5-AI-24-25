//damiano ucciardo 5^AI

public class Contatore implements Runnable {
	 
	public int  max;
	public int x2; 
	public int conta = 0;
	 
	public Contatore(int n, int x) {
		this.max = n;
		this.x2 = x; 
	}
	
	@Override
	public void run() {
		
		String nome = Thread.currentThread().getName();
		long tid = Thread.currentThread().getId();
		
		String thread = nome + "(" +tid+ ")";
		System.out.println(thread + " inizio a contare \n ");
		
		while (conta == x2) {
			x2++;
			conta++; 
		}
		
		System.out.print(" COMPLETATO \n ");
		
	}

}