//damiano ucciardo 5^AI

package es_si_va_balla;

import java.util.Random;

public class discoteca extends Thread implements Runnable {
		 
	private int numero = 0; //indica il numero delle persone
	private int n2; //tempo da decrementare per uscire dalla discoteca 
	private boolean usicta = true;
			//tempo randomico di presenza in discoteca
	
	public discoteca (int n) {
		this.n2 = n;
	}
		
	public void run () {
		
		entra();
		
		String nome = Thread.currentThread().getName();
		long tid = Thread.currentThread().getId();
		
		String thread = nome + "(" +tid+ ")";
				
		while (n2 == 0) {
			System.out.println(thread + " Me ne vado tra " + n2 + " secondi  \n ");
			n2--; 
		}
		
		esci();
		
	}
	//metodi per incrementare il contatore delle perosne all'interno della discoteca 
	public int entra() {
		return numero++;
	}
	
	public int esci() {
		return numero--;
	}
}