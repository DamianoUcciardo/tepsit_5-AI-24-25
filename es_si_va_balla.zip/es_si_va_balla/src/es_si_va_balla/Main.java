//damiano ucciardo 5^AI 

package es_si_va_balla;

import java.util.Scanner;
import java.util.Random;

public class Main {
	//main
	public static void main(String[] args) {
		
		Random r = new Random();
		Scanner s = new Scanner(System.in);
		
		int t; //attributo per le persone e per il tempo
		int n = r.nextInt(1000);
		
		System.out.println(" Quante persone ci sono a balla? ");
		t = s.nextInt();
		
		discoteca[] persona = new discoteca[t]; //array di persone (thread)
		
		//thread entarno in discoteca
		for(int i = 0; i < persona.length; i++) {
			persona[i] = new discoteca(i);
			persona[i].start();
			
	        while (true) {
	            try {
	                Thread.sleep(1000); //ogni secondo viene stampato il num di perosne in discoteca
	                System.out.println(" In discoteca ci sono " + i + " persone \n " );
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	                break;
	            }
	        }
		}	
	}
}